import alt from '../alt'

class NavbarActions {
  constructor () {
    this.generateActions(
      'updateAjaxAnimation'
    )
  }
}

export default alt.createActions(NavbarActions)
