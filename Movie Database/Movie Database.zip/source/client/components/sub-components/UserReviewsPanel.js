import React, { Component } from 'react'

export default class UserReviewsPanel extends Component {
  render () {
    return (
      <div className='container' >
        <div className='list-group' >
          Hello from UserReviewsPanel
        </div>
      </div>
    )
  }
}
