import React from 'react'

export default class UserVotedMoviesPanel extends React.Component {
  render () {
    return (
      <div className='list-group' >
        Hello from UserRatedMoviesPanel
      </div>
    )
  }
}