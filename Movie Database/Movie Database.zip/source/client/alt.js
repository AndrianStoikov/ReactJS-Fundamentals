
let Alt = require('alt')

export default new Alt()
